if [ "$1" == "-h" ]
then
	echo "******************************************************************************************"
	echo "*                                                                                        *"
	echo "*                      This is Linux version of Rjml                                     *"
	echo "*       a fast program for detecting hybridization from species trees                    *"
	echo "*                                                                                        *"
	echo "*                         Coded by Chen's Lab at CIB                                     *"
	echo "*                                                                                        *"
	echo "*    Usage                                                                               *"
	echo "*    (1)Display help information:                                                        *"
	echo "*      ./runRjml.sh -h                                                                   *"
	echo "*                                                                                        *"
	echo "*    (2)Install JML-SIM and dependent R packages:                                        *"
	echo "*      ./runRjml.sh -il                                                                  *"
	echo "*                                                                                        *"
	echo "*    (3)Running :                                                                        *"
	echo "*      ./runRjml.sh jml.tpi.ctl rosa.species.trees tpi.phy 0.1 8                         *"
	echo "*                                                                                        *"
	echo "*      'jml.tpi.ctl' is jml-sim control file for simulate sequences                      *"
	echo "*      'tpi.phy' is the original sequence file                                           *"
	echo "*      'rosa. species. trees' is the species tree file                                   *"
	echo "*      '0.1' and '8' are the significance level and the number of threads, respectively  *"
	echo "*                                                                                        *"
	echo "******************************************************************************************"
	exit
fi
if [ "$1" == "-il" ]
then
sudo cp Rjml.R /usr/local/bin
Rscript ./Rjml.R
	if  [ "$(whereis jml-sim)" == "jml-sim: /usr/local/bin/jml-sim" ];
	then
		echo "JML-SIM is  installed"
	else
		echo "JML-SIM is not installed"
		read -p "Whether to install JML-SIM（y|n）:"  -n 1 OK
		if [ ${OK} = "y" ] || [ ${OK} = "Y" ]
		then
			echo
			echo "Begin Install JML-SIM……"
			tar zxvf jml_sim.tar.gz
			cd jml_sim
			make
			sudo cp jml-sim /usr/local/bin/
			cd ../
			if [ "$(whereis jml-sim)" == "jml-sim: /usr/local/bin/jml-sim" ];
			then
				echo "Install JML-SIM successfully"
			else
				echo "Failed to install JML-SIM"
			fi
		else
			echo "You chose not to install JML-SIM"
		fi
	fi
	exit  
fi
ctl=$1
sptree=$2
seqence=$3
alpha=$4
core=$5
if [ "$1" == "" ] || [ "$2" == "" ]|| [ "$3" == "" ]|| [ "$4" == "" ]|| [ "$5" == "" ]
then
	echo "no input file，please input "./runRjml.sh -h" to show usage information"
	exit
fi
jml-sim -c $ctl -t $sptree -d $seqence
Rscript Rjml.R $seqence $alpha $core
